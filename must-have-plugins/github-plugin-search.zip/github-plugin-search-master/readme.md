Read about Github Plugin Search and watch a demo video at [WordPress Tavern](http://www.wptavern.com/how-to-install-wordpress-plugins-directly-from-github).

### Changelog

#### 0.3

* Display author name, avatar, and links to author profile and plugin page. [View screenshot](https://dl.dropboxusercontent.com/s/ay0igfc2rrziotc/git-plugin-search-author-avatars.png).
* Hide version and rating. Can't display these yet -- not without additional API calls.

#### 0.2

* WordPress 3.7 compatibility.
* Require minimum amount of stars for repos to show up in search results.

#### 0.1

* Initial release.